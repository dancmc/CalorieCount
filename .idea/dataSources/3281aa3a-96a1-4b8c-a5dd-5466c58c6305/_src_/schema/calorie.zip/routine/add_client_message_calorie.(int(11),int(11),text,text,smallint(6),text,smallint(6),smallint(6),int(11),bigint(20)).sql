CREATE PROCEDURE add_client_message_calorie(IN userid       INT, IN platform_id INT, IN platform_username TEXT,
                                            IN messagetext  TEXT, IN image_type SMALLINT(6), IN file_location TEXT,
                                            IN image_height SMALLINT(6), IN image_width SMALLINT(6), IN image_size INT,
                                            IN time_entered BIGINT)
  BEGIN
	IF image_type IS NOT NULL THEN
		INSERT INTO file_index(file_location) VALUES (file_location);
        SET @fileindex = LAST_INSERT_ID();
		INSERT INTO images(image_id,uploader_id, image_type, file_location, image_height, image_width, image_size)  
		VALUES (@fileindex, userid, image_type, file_location, image_height, image_width, image_size);
        INSERT INTO file_permissions(file_id, user_id)
        VALUES (@fileindex, userid);
	END IF;
    
    INSERT INTO messaging_platforms(username, platform_id, `timestamp`, image_id, `text`)
    VALUES (platform_username, platform_id, time_entered, @fileindex, messagetext);
    INSERT INTO calorie_entries(user_id, `timestamp`, image_id, client_comment)
    VALUES (userid, time_entered, @fileindex, messagetext);
    SELECT LAST_INSERT_ID() as t;
    
END;
